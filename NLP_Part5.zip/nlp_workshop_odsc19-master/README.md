# ODSC India 2019 - NLP Workshop 


Contains all tutorials and hands-on examples for the ODSC 2019 Workshop. Use the following button to open the repo in google colab

### Open Repository in Colab: [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/github/dipanjanS/nlp_workshop_odsc19)


## Open in Jupyter nbviewer  
[![Open in nbviewer](https://upload.wikimedia.org/wikipedia/commons/thumb/3/38/Jupyter_logo.svg/250px-Jupyter_logo.svg.png)](https://nbviewer.jupyter.org/github/dipanjanS/nlp_workshop_odsc19/tree/master)
